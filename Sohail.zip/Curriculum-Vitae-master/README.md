# Curriculum-Vitae
My CV using HTML,CSS,JavaScript

Link:https://mafzalkhan1997.github.io/Curriculum-Vitae/
